//alert("this is my file")
//document.write(5-2);
//window.alert("hi i am amrit");
//document.write(prompt("this is name"))
////////////////////////////////////////////////
//name=prompt("enter name");
//document.write(name);
//////////////////////////////////////////////
//confirm("would you like to exit")
//document.write(confirm("would you like to exit"))
//////////////////Dynemic valu//////////////////////////////////////////////////
<h1 id="my-content"> </h1>
document.getElementById("my-content").innerHTML = "my name is Amrit"

/////////////////////////////Variable///////////////////////////////////////////