package com.api.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.api.entity.Plan;

public interface PlanRepo extends JpaRepository<Plan, Integer> {

}
