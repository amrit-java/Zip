package com.api.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDate;
import java.util.Date;

import lombok.Data;

@Entity
@Data
@Table(name="PLAN_MASTER")
public class Plan {
	@Id
	@GeneratedValue
	@Column(name="PLAN_ID")
	private Integer planId;
	
	@Column(name="PLAN_NAME")
	private String planName;
	
	@Column(name="PLAN_START_DATE")
	private String planStartDate;
	
	@Column(name="PLAN_END_DATE")
	private String planEndDate;
	
	@Column(name="ACTIVE_SW")
	private String activeSw;
	
	@Column(name="PLAN_CATEGORY_ID")
	private String planCategoryId;
	
	@Column(name="CREATE_BY")
	private String createBy;
	
	@Column(name="UPDATED_BY")
	private String updatedBy;
	
	
	@Column(name="CREATE_DATE", updatable=false)
	@CreationTimestamp
	private LocalDate createDate;
	
	@Column(name="UPDATE_DATE", insertable=false)
	@UpdateTimestamp
	private LocalDate updateDate;

}
