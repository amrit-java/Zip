package com.api.service;

import java.util.List;
import java.util.Map;

import com.api.entity.Plan;

public interface PlanService {
	
	public Map<Integer, String> getPlanCategories();
    
	public boolean savePlan(Plan plan);
	
	//view all data
	
	public List<Plan> getAllPlans();
	
	//edit
	
	public Plan getPlanById(Integer planId);
	
	public boolean updatePlan(Plan plan);
	
	
	//delete
	public boolean deletePlanById(Integer planId);
	//active,deactive
	public boolean planStatusChange(Integer planId, String status);//2 parameter
	//  
	
}
