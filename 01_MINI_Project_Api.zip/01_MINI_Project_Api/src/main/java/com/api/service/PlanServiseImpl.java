package com.api.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.api.entity.Plan;
import com.api.entity.PlanCateogry;
import com.api.repo.PlanCategoryRepo;
import com.api.repo.PlanRepo;
@Service
public class PlanServiseImpl implements PlanService {
      @Autowired
	private PlanRepo planRepo;
      @Autowired
      private PlanCategoryRepo planCategoryRepo;
	
	
	@Override
	public Map<Integer, String> getPlanCategories() {
		List<PlanCateogry> categories = planCategoryRepo.findAll();//all records avaibale in this table
		//how to convert list to map now
		Map<Integer, String> cateogryMap= new HashMap<>();
		
		categories.forEach(category ->{
		cateogryMap.put(category.getCategoryId(),category.getCategoryName());
		});
		return cateogryMap;
	}
// insert the table
	@Override
	public boolean savePlan(Plan plan) {
		
		Plan saved = planRepo.save(plan);
		
//		if(saved.getPlanId()!=null) {
//			return true;
//		}else {
//			return false;
//		}
		
		//ternary operator
		
	//	return saved.getPlanId()!=null ? true :false;
		  return saved.getPlanId()!=null;
   }

	@Override
	public List<Plan> getAllPlans() {
		
		return planRepo.findAll();
	}

	@Override
	public Plan getPlanById(Integer planId) {
	  Optional<Plan> findById = planRepo.findById(planId);
	  //optional is a container,within this container our object may avaliable,object may not be abliable 
		if(findById.isPresent()) {
			
			return findById.get();
		}
	  return null;
	}
//update
	@Override
	public boolean updatePlan(Plan plan) {
		Plan save = planRepo.save(plan);//upsert:-inseration+updation,when it will insert-if the primary key value not available
		//update:-when primary key value is present
		
		return plan.getPlanId()!=null;
	}
//**********************delete
	@Override
	public boolean deletePlanById(Integer planId) {
	      
		boolean status=false;
		try {
			planRepo.deleteById(planId);
			status=true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return true;
	}

	@Override
	public boolean planStatusChange(Integer planId, String status) {
		
//		Plan plan=new Plan();
//		plan.setPlanId(planId);
//		plan.setActiveSw(status);
//		
//		planRepo.save(plan);
		
		Optional<Plan> findById = planRepo.findById(planId);
		 if(findById.isPresent()) {
			Plan plan = findById.get();
			plan.setActiveSw(status);
			planRepo.save(plan);
			return true;
		 }
		
		return false;
	}

}
