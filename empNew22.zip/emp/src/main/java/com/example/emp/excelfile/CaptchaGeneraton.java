package com.example.emp.excelfile;

import java.awt.Color;
import java.io.ByteArrayOutputStream;

import javax.imageio.ImageIO;

import cn.apiclub.captcha.Captcha;
import cn.apiclub.captcha.backgrounds.GradiatedBackgroundProducer;
import cn.apiclub.captcha.text.producer.DefaultTextProducer;

public class CaptchaGeneraton {
        private static final char[] DEFAULT_CHARS = new char[] { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'm',
                        'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H',
                        'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '1', '2', '3',
                        '4', '5', '6', '7', '8', '9' };

        public static Captcha createCaptcha(Integer width, Integer height) {

                return new Captcha.Builder(width, height)
                                .addBackground(new GradiatedBackgroundProducer(Color.LIGHT_GRAY, Color.WHITE))
                                .addText(new DefaultTextProducer(5, DEFAULT_CHARS)).addNoise().build();
        }

        public static byte[] encodeCaptcha(Captcha captcha) {
                byte[] byteArray = null;

                try (ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream()) {
                        ImageIO.write(captcha.getImage(), "jpg", byteArrayOutputStream);
                        byteArray = byteArrayOutputStream.toByteArray();
                } catch (Exception e) {
                        e.printStackTrace();
                }
                return byteArray;
        }
}
