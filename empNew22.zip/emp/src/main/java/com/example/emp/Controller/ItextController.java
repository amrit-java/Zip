package com.example.emp.Controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.emp.Service.ItextReportService;
@RestController
public class ItextController {
	
	 @Autowired 
	 private ItextReportService pdfReportService;
	
	@GetMapping("/generate-report")
	public void generateStudentReport(HttpServletResponse response) throws Exception {
	    // Generate the student report as a PDF
	    byte[] pdfBytes = pdfReportService.generateStudentReport();

	    // Set response headers
	    response.setContentType("application/pdf");
	    response.setHeader("Content-Disposition", "inline; filename=student_report.pdf");

	    // Write the PDF bytes to the response
	    response.getOutputStream().write(pdfBytes);
	}

}
