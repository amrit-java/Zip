package specialiterator;

import java.util.Arrays;
import java.util.List;
import java.util.Spliterator;
//Spliterator we can use to traverse both Collections and Stream,it is interface,support parallel programming,
//can't be used with Map Implementation class
public class Iterator {

	public static void main(String[] args) {
		List<String> names = Arrays.asList("Sachin","Sehwag","Dhoni","Rahul");
		Spliterator<String> spliterator = names.stream().spliterator();
		spliterator.forEachRemaining(e ->System.out.println(e));
	}

}
