package foreach;

import java.util.ArrayList;

//Q)write a java program to store numbers in ArrayList and sort numbers in descending order using for each method
public class NumbersSort2 {

	public static void main(String[] args) {
		ArrayList<Integer> al= new ArrayList<>();
		al.add(5);
		al.add(3);
		al.add(4);
		al.add(1);
		al.add(2);
		//using for loop to printed
		for(int i=0;i<al.size();i++) {
			System.out.println(al.get(i));
		}
		
		System.out.println("========================");
		//using forEach loop to printed
		for(int i : al) {
			System.out.println(i);
		}
		
		System.out.println("========================");
	   //using forEach method to printed
		
        al.forEach(i -> System.out.println(i));
	}

}