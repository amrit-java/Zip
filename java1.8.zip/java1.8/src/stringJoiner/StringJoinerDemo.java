package stringJoiner;

import java.util.StringJoiner;

public class StringJoinerDemo {

	public static void main(String[] args) {
		
		StringJoiner sj = new StringJoiner("-");
		sj.add("Amrit");
		sj.add("Kumar");
		sj.add("Bhardwaj");
		
		System.out.println(sj);
		
		StringJoiner sj2 = new StringJoiner("-","(",")" );
		sj2.add("Amrit");
		sj2.add("Kumar");
		sj2.add("Bhardwaj");
		System.out.println(sj2);
	}

}
