package methodeREfrance;

@FunctionalInterface
interface MyInterface{
	public void m1();
}

public class MethodRef1 {
	
	public static void m2() {
		System.out.println("This is m2() method");
	}
	
	public static void main(String[] args) {
		//class
		//MethodRef1.m2();//o/p:-This is m2() method
		
		//static method reference
		MyInterface mi= MethodRef1::m2;
		mi.m1(); //o/p:-This is m2() method
		
		//Lambda 
		MyInterface mk =()->System.out.println("hii");
		mk.m1();
		
	}
	

}
