package methodeREfrance;
//Approach:2
//write a program to print number from 1 to 5 using Thread with the help of Runnable Interface
public class ThreadDemo2 {
	public static void main(String[] args) {
		 Runnable r = new Runnable() {

			@Override
			public void run() {
				for(int i=1; i<=5;i++) {
					System.out.println(i);
				}
				
			}
			 
		 };
		 Thread t = new Thread(r);
		 t.start();
	}

}
