package methodeREfrance;

import java.util.function.Supplier;

public class Test {
	public static void main(String[] args) {
	//	Doctor d= new Doctor();//Doctor constructor...
		
		//constructor reference
		Supplier<Doctor> s=Doctor::new;
		//System.out.println(s.get().hashCode());
		Doctor doctor= s.get();
		System.out.println(doctor.hashCode());
	}

}
class Doctor{
	//constructor
	public Doctor() {
		System.out.println("Doctor constructor...");
	}
}