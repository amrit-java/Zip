package methodeREfrance;
//@):-write a program to print number from 1 to 5 using Thread with the help of Runnable Interface
//Approach:1
public class ThreadDemo1 implements Runnable{

	public static void main(String[] args) {
		ThreadDemo1 td = new ThreadDemo1();
		Thread t = new Thread(td);
		t.start();

	}

	@Override
	public void run() {
		for(int i=1; i<=5;i++) {
			System.out.println(i);
		}
		
	}

}
