package methodeREfrance;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

//Q)write a java program to store numbers in ArrayList and sort numbers in descending order 
public class NumbersSort1 {

	public static void main(String[] args) {
		ArrayList<Integer> al= new ArrayList<>();
		al.add(5);
		al.add(3);
		al.add(4);
		al.add(1);
		al.add(2);
		
		System.out.println("Before sort :" + al);
		
	//	Collections.sort(al, new NumberComparateor());
		//Collections.sort(al,(i,j)->i.compareTo(j));
		Collections.sort(al,(i,j)->(i>j) ? -1 : 1);
		System.out.println("After sort ::"+al);

	}

}

class NumberComparateor implements Comparator<Integer>{

	@Override
	public int compare(Integer i, Integer j) {
		if(i>j) {
			return -1;
		}else if (i<j) {
			return 1;
		}
		return 0;
	}
	
}
