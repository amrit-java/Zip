package streamApi;

import java.util.Arrays;
import java.util.List;

public class flatMap {

	public static void main(String[] args) {
		
		List<String> javacourses = Arrays.asList("core java","adv java","spring boot");
		
		List<String> uicourses  = Arrays.asList("html","css","bs","js");
		
		List<List<String>> courses  = Arrays.asList(javacourses,uicourses);
		
		courses.stream().forEach(c ->System.out.println(c));
		
	/*	o/p:-[core java, adv java, spring boot]
		[html, css, bs, js]*/
		
		courses.stream().flatMap(s -> s.stream()).forEach(c -> System.out.println(c));
		
	/*o/p:-	core java
		adv java
		spring boot
		html
		css
		bs
		js*/
		
  
	}

}
