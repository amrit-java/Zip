package streamApi;

import java.util.Arrays;
import java.util.List;

public class FirstDemo3 {
	public static void main(String[] args) {
		List<String> names = Arrays.asList("John", "Anushka", "Robert", "Anupama", "Smith","Ashok");
		
		//charter A print using stream Api
	//	names.stream().filter(i -> i.startsWith("A")).forEach(i-> System.out.println(i));
		names.stream().filter(i -> i.endsWith("a")).forEach(i-> System.out.println(i));
	}

}
