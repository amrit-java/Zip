package streamApi;

import java.util.Arrays;
import java.util.List;
//SlicingOperationWithStream :limit(),skip(),distinct() 3 method
public class SlicingOperationWithStream {

	public static void main(String[] args) {
		List<String> javacourses = Arrays.asList("core java","adv java","spring boot","restapi","microservices");
		javacourses.stream().limit(3).forEach(c -> System.out.println(c));
		javacourses.stream().skip(3).forEach(c -> System.out.println(c));
		
		List<String> names = Arrays.asList("Raja","Rani","Guru","Rani","Guru");
		names.stream().distinct().forEach(name -> System.out.println(name));
	}

}
