package streamApi;



import java.util.Arrays;
import java.util.List;
//MatchingOperationWithStream:-anyMatch(),allMatch(),noneMatch() this method return boolean
public class MatchingOperationWithStream {

	public static void main(String[] args) {
		 Person p1 = new Person("John","USA");
		 Person p2 = new Person("Steve","JAPAN");
		 Person p3 = new Person("Ashok","INDIA");
		 Person p4 = new Person("Ching","CHINA");
		 
		 List<Person> person = Arrays.asList(p1,p2,p3,p4);
		 
		 boolean status = person.stream().anyMatch(p -> p.country.equals("INDIA"));
		 System.out.println("Any Indian Available ? :: "+ status);//true
		 
		 boolean status1 = person.stream().anyMatch(p -> p.country.equals("CANADA"));
		 System.out.println("Any Canadian Available ? :: "+ status1);//false
		 
		 boolean status3 = person.stream().allMatch(p -> p.country.equals("INDIA"));
		 System.out.println("Any Indian Available ? :: "+ status3);//false
		 
		 boolean status4 = person.stream().noneMatch(p -> p.country.equals("MEXICO"));
		 System.out.println("NO MPERSONS FROM MEXICO ? :: "+ status4);//true
		 
		 
	}

}

class Person{
	 String name;
	 String country;
	public Person(String name, String country) {
		this.name = name;
		this.country = country;
	}
	@Override
	public String toString() {
		return "Person [name=" + name + ", country=" + country 
				;
	}
	 
}
