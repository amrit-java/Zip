package streamApi;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class FirstDemo2 {
	public static void main(String[] args) {
		//Approach-1
		List<Integer> list = Arrays.asList(66, 32, 45, 12, 20);
		//1st
		/*for(Integer i : list) {
			if(i> 20) {
				System.out.println(i);
			}
		}*/
		
		//2nd
		/*Stream<Integer> stream = list.stream();//stream method
		Stream<Integer> filter = stream.filter(i -> i>20);
		filter.forEach(i-> System.out.println(i));
		*/
		//3rd
		list.stream().filter(i -> i>20).forEach(i-> System.out.println(i));
	}
}
