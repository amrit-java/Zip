package streamApi;

import java.util.Arrays;
import java.util.List;

public class MappingOperation1 {
	public static void main(String[] args) {
		List<String> names = Arrays.asList("Ashoke", "Anil", "Raju", "Rani", "John", "Akash", "Charles");
		
		 //print name with its length which are starting 'A' using Stream API
		
		names.stream().filter(name -> name.startsWith("A")).map(name -> name+"-"+name.length()).forEach(name -> System.out.println(name));
		
	}

}
