package streamApi;

import java.util.Arrays;
import java.util.List;

public class MappingOperation {
	public static void main(String[] args) {
		List<String> names = Arrays.asList("india", "usa", "uk", "japan");
		 
		/*for(String name : names) {
			System.out.println(name.toUpperCase());
		}*/
		//use map method
		names.stream().map(name-> name.toUpperCase()).forEach(n->System.out.println(n));
		
		//use mapToInt
		names.stream().mapToInt(name-> name.length()).forEach(n->System.out.println(n));
		
	}

}
