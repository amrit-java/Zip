package DateAndTimeApiChanges;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Period;
import java.util.Date;

public class NewDateDemo {
	public static void main(String[] args) {
		
		LocalDate of = LocalDate.of(2021, 1, 20);
		System.out.println(of);//o/p:-2021-01-20
		
		
		Date d1 = new Date();
		System.out.println(d1);//o/p:-Wed Sep 13 03:38:18 IST 2023
		
		LocalDate date = LocalDate.now();
		System.out.println(date);//o/p:-2023-09-13
		
		date = date.plusDays(3);//add 3 days for current day
		System.out.println(date);//o/p:-2023-09-16
		
		date = date.plusMonths(1);
		System.out.println(date);//o/p:-2023-10-16
		
		date = date.plusYears(1);
		System.out.println(date);//o/p:-2024-10-16
		
		boolean leapYear = LocalDate.parse("2023-09-13").isLeapYear();
		System.out.println("Leap Year :: "+ leapYear);//o/p:-Leap Year :: false
		
		boolean before = LocalDate.parse("2022-09-13").isBefore(LocalDate.parse("2023-09-13"));
        System.out.println("Before :: "+ before);
        
        LocalTime time= LocalTime.now();
        System.out.println(time);
        time= time.plusHours(2);
        System.out.println(time);//o/p:-03:59:11.341-05:59:11.341
        
        LocalDateTime datetime = LocalDateTime.now();
        System.out.println(datetime);//o/p:-2023-09-13T03:59:11.341
        
        Period between = Period.between(LocalDate.parse("1991-05-20"), LocalDate.now());
        System.out.println(between);//o/p:-P32Y3M24D
        
        Duration between2 = Duration.between(LocalTime.parse("18:00"), LocalTime.now());
        System.out.println(between2);//o/p:-PT-13H-45M-39.642S
		
		
	}

}
