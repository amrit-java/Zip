package DateAndTimeApiChanges;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateDemo {

	public static void main(String[] args) throws Exception {
		Date d = new Date();
		System.out.println(d);//o/p:-Wed Sep 13 03:06:14 IST 2023
       
		//converting Date to String
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String format = sdf.format(d);
		System.out.println(format);//o/p:-13/09/2023
		// dd/MM/yyyy
		
		SimpleDateFormat sdf1 = new SimpleDateFormat("MM/dd/yyyy");
		String format1 = sdf1.format(d);
		System.out.println(format1);//o/p:-09/13/2023
		
		//convert String to Date
		
		SimpleDateFormat sdf3 = new SimpleDateFormat("yyyy-MM-dd");
		Date parseDate = sdf3.parse("2023-09-13");
		System.out.println(parseDate);//o/p:-Wed Sep 13 00:00:00 IST 2023
          
	}

}
