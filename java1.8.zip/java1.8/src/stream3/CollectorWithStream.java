package stream3;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class CollectorWithStream {
	  public static void main(String[] args) {

			Person p1 = new Person("John", "USA");
			Person p2 = new Person("Steve", "JAPAN");
			Person p3 = new Person("Ashok", "INDIA");
			Person p4 = new Person("Ching", "CHINA");
			Person p5 = new Person("kumar", "INDIA");

			List<Person> persons = Arrays.asList(p1, p2, p3, p4, p5);

			// 1.@)Use filter to find the first person from INDIA
			List<Person> person = persons.stream().filter(p -> p.country.equals("INDIA")).collect(Collectors.toList());

			person.forEach(i -> System.out.println(i));//Person [name=Ashok, country=INDIA, Person [name=kumar, country=INDIA

			// 2.@)collect name of persons who are belongs to india and store into names collection
			
			List<String> names = persons.stream().filter(p -> p.country.equals("INDIA")).map(p -> p.name).collect(Collectors.toList());
			System.out.println(names);//[Ashok, kumar]
		}
	}

	 class Person {
		 
	    String name;
	    String country;

	    public Person(String name, String country) {
	    	
	        this.name = name;
	        this.country = country;
	    }

		@Override
		public String toString() {
			return "Person [name=" + name + ", country=" + country ;
		}

		
	}


