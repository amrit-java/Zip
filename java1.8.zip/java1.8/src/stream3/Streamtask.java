package stream3;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
//@)Write a program to get MAX,MIN,
import java.util.stream.Stream;
//@) Write a Program to get MAX, MIN AND AVG  Salary from given employees data
public class Streamtask {

	public static void main(String[] args) {
		Employee e1 = new Employee(1, "Robert", 26500.00);
		Employee e2 = new Employee(1, "Abraham", 46500.00);
		Employee e3 = new Employee(1, "Ching", 36500.00);
		Employee e4 = new Employee(1, "David", 16500.00);
		Employee e5 = new Employee(1, "Cathy", 25500.00);
		
	//Approach-1:one by one max,and min	
	//	Stream<Employee> stream = Stream.of(e1,e2,e3,e4,e5);
		
		//Optional<Employee> max = stream.collect(Collectors.maxBy(Comparator.comparing(e -> e.salary)));
	//	System.out.println("max Salary :: "+ max.get().salary);
		
		//Optional<Employee> min = stream.collect(Collectors.minBy(Comparator.comparing(e -> e.salary)));
		//System.out.println("min Salary :: "+ min.get().salary);
		
		//Approach-2
		List<Employee> list = Arrays.asList(e1,e2,e3,e4,e5);
		
		//Maximum Salary:-Collectors.maxBy()
		Optional<Employee> max = list.stream().collect(Collectors.maxBy(Comparator.comparing(e -> e.salary)));
		System.out.println("max Salary :: "+ max.get().salary);
		
		//Minimum Salary:-Collectors.minBy()
		Optional<Employee> min = list.stream().collect(Collectors.minBy(Comparator.comparing(e -> e.salary)));
		System.out.println("min Salary :: "+ min.get().salary);
		
		//Average Salary:-Collectors.averagingDouble()
		Double collect = list.stream().collect(Collectors.averagingDouble(e -> e.salary));
		System.out.println(collect);
	}

}

class Employee{
	int id;
	String name;
	double salary;
	
	public Employee(int id, String name, double salary) {
		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	/*
	 * @Override public String toString() { return "Employee [id=" + id + ", name="
	 * + name + ", salary=" + salary ; }
	 */
	
}
