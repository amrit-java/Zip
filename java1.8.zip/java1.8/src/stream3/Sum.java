package stream3;

import java.util.Arrays;

public class Sum {

	public static void main(String[] args) {

		int[] nums = { 1, 2, 3, 4, 5 };
		
	/*	int Sum = 0;
		for (int i : nums) {
			Sum = Sum + i;

		}
		System.out.println(Sum);*/
		
		//Strime
		int reduce = Arrays.stream(nums).reduce(0,(a,b)->a+b);
		System.out.println(reduce);
	}

}
