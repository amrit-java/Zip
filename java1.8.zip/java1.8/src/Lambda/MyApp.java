package Lambda;

@FunctionalInterface //:-A functional interface is an interface that has exactly one abstract method, which makes it eligible for use with lambda expressions.
 interface MyInterface{  //It contains a single abstract method m2()
	public void m2();
	 
 }
public class MyApp {
	public static void main(String args []) {
		MyInterface mit =  () -> System.out.println("m2 method called...");
		mit.m2();
	}

}
