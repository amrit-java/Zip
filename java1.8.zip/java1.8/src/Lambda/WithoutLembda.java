package Lambda;

interface MyInterfaceOne{
	public void m1();
}
//abstract methode
public class WithoutLembda implements MyInterfaceOne{
	
	public void m1() {
		System.out.println("m1 method called...");
		
	}
public static void main(String args []) {
	WithoutLembda mao = new WithoutLembda();
	mao.m1();
}

	
}
//when interface having only one abstract method (m1),my class is implements interface,my class is override the method,in that i am creating of object in the class ,i am calling the method
//this is normal style of the program.