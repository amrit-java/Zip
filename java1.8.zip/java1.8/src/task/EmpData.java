package task;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;



public class EmpData {

	public static void main(String[] args) {
		List<Employee> emps= new ArrayList<Employee>();
		
		emps.add(new Employee(1,"Jhansi",32,"Female","HR",2011,25000.0));
		emps.add(new Employee(2,"Smith",25,"Male","sales",2015,13500.0));
		emps.add(new Employee(3,"David",29,"Male","Infrastructure",2012,18000.0));
		emps.add(new Employee(4,"Orlen",28,"Male","Development",2014,32500.0));
		emps.add(new Employee(5,"Charles",27,"Male","HR",2013,22700.0));
		emps.add(new Employee(6,"Cathy",43,"Male","Security",2016,10500.0));
		emps.add(new Employee(7,"Ramesh",35,"Male","Finance",2010,27000.0));
		emps.add(new Employee(8,"Surash",31,"Male","Development",2015,34500.0));
		emps.add(new Employee(9,"Gita",24,"Female","sales",2016,11500.0));
		emps.add(new Employee(10,"Mahesh",38,"Male","Security",2015,11000.0));
		emps.add(new Employee(11,"Gouri",27,"Female","Infrastructure",2014,15700.0));
		emps.add(new Employee(12,"Nithin",25,"Male","Development",2016,28200.0));
		emps.add(new Employee(13,"Swati",27,"Female","Finance",2013,21300.0));
		emps.add(new Employee(14,"Buttler",24,"Male","sales",2017,10700.0));
		emps.add(new Employee(15,"Ashok",23,"Male","Infrastructure",2018,12700.0));
		emps.add(new Employee(16,"Sanvi",26,"Female","Development",2015,28900.0));
		
		//1.How many male and female employees are there in the organization,use concept:-Collectors.groupingBy()
		
		Map<String, Long> map1 = emps.stream().collect(Collectors.groupingBy(Employee::getGender, Collectors.counting()));
		System.out.println(map1);//{Female=5, Male=11}
		
		//2.Print the name of all department in the organization?
		
		emps.stream().map(e -> e.department).forEach(name -> System.out.println(name));//print all department name
		
		emps.stream().map(Employee::getDepartment).distinct().forEach(name -> System.out.println(name));//Unique department name print
		
		//3.What is the average of male and email employee?
		
		Map<String, Double> map2 = emps.stream().collect(Collectors.groupingBy(Employee::getGender, Collectors.averagingInt(Employee :: getAge)));
		System.out.println(map2);//{Male=29.818181818181817, Female=27.2}
		
		//4.Get the details of highest paid employee in the organization
		Optional<Employee> optional = emps.stream().collect(Collectors.maxBy(Comparator.comparingDouble(Employee :: getSalary)));
		if(optional.isPresent()) {
			Employee employee = optional.get();
			System.out.println(employee);
		}
		
		
		//5.get the names of all employee who have join after 2015?
		emps.stream().filter(e -> e.yearOfJoining >2015).map(e -> e.name).forEach(name -> System.out.println(name));
		
		
		//6.count the Number o employees in each department?
		Map<String, Long> map3 = emps.stream().collect(Collectors.groupingBy(Employee::getDepartment, Collectors.counting()));
			System.out.println(map3);//{Development=4, Finance=2, Infrastructure=3, HR=2, Security=2, sales=3}
		
		//7.what is the average salary of each department?
			Map<String, Double> map4 = emps.stream().collect(Collectors.groupingBy(Employee::getDepartment, Collectors.averagingDouble(Employee :: getSalary)));
			System.out.println(map4);//{Development=31025.0, Finance=24150.0, Infrastructure=15466.666666666666, HR=23850.0, Security=10750.0, sales=11900.0}
			
		//8.Get the details of youngest male employee in the Development department?
			Optional<Employee> optional2 = emps.stream().filter(e -> e.getGender().equals("Male")&& e.getDepartment().equals("Development"))
			.min(Comparator.comparing(Employee :: getAge));
			
			if(optional2.isPresent()) {
				System.out.println(optional2.get());
			}
		//9.who has most working experience in the organization?
			Optional<Employee> optional3 = emps.stream().collect(Collectors.minBy(Comparator.comparing(Employee::getYearOfJoining)));
			System.out.println(optional3);
			
		//10.how many male and female employees are there in the Sales team
			Map<String, Long> map5 = emps.stream().filter(e -> e.getDepartment().equals("sales"))
			.collect(Collectors.groupingBy(Employee::getGender, Collectors.counting()));
			System.out.println(map5);
			
		//11.what is the average salary of male and female employee?
			Map<String, Double> map6 = emps.stream()
					.collect(Collectors.groupingBy( Employee::getGender,Collectors.averagingDouble(Employee::getSalary)));
			 map6.forEach((gender, avgSalary) -> {
		            System.out.println("Average salary for " + gender + " employees: " + avgSalary);
		        });
			
		//12.List down the name of all employees in each department?
			 Map<String, List<String>> emp = emps.stream()
			            .collect(Collectors
			            .groupingBy(Employee::getDepartment,Collectors.mapping(Employee::getName, Collectors.toList())));

			        emp.forEach((department, employeeNames) -> {
			            System.out.println("Employees in " + department + " department: " + employeeNames);
			        });
			 
		//13. what is the average salary and total salary of the whole organization?
			     // Calculate the average salary for the whole organization
			        double averageSalary = emps.stream().mapToDouble(Employee::getSalary).average().orElse(0.0);

			            // Calculate the total salary for the whole organization
			            double totalSalary = emps.stream().mapToDouble(Employee::getSalary).sum();

			            // Print the average and total salaries
			            System.out.println("Average salary for the whole organization: " + averageSalary);
			            System.out.println("Total salary for the whole organization: " + totalSalary);   
			     
			        
			        
		//14.Separate the employees who are youngest or equal to 25 years from those employees who are older than 25 years ?
			         // Separate employees into two groups: younger or equal to 25 and older than 25
			            List<Employee> youngerOrEqual25 = emps.stream().filter(employee -> employee.getAge() <= 25).collect(Collectors.toList());

			            List<Employee> olderThan25 = emps.stream().filter(employee -> employee.getAge() > 25).collect(Collectors.toList());

			            // Print the separated groups
			            System.out.println("Employees 25 years old or younger:");
			            youngerOrEqual25.forEach(employee -> System.out.println("Age: " + employee.getAge()));

			            System.out.println("\nEmployees older than 25 years:");
			            olderThan25.forEach(employee -> System.out.println("Age: " + employee.getAge()));
			            
		//15.who is the oldest employee in the organization?What is his age which department which department he belong to ?
			     
			         
			
			//Maximum Salary:-Collectors.maxBy()
			Optional<Employee> max = emps.stream().collect(Collectors.maxBy(Comparator.comparing(e -> e.salary)));
			System.out.println("max Salary :: "+ max.get().salary);
			
	    // Second height salary
			Optional<Employee> findFirst = emps.stream().sorted(Comparator.comparing(Employee::getSalary).reversed()).skip(1).findFirst();
			System.out.println(findFirst.get());
			
			/*
			 * Optional<Employee> findFirst =
			 * emps.stream().sorted(Comparator.comparing(Employee::getSalary).reversed())
			 * .collect(null)
			 */
			System.out.println("--Second height salary--");
			List<Employee> collect = emps.stream().sorted(Comparator.comparing(Employee::getSalary).reversed())
					.collect(Collectors.toList());
			System.out.println(collect.get(4));

	}

}

class Employee{
	
	int id;
	String name;
	int age;
	String gender;
	String department;
	int yearOfJoining;
	double salary;
	
	public Employee(int id, String name, int age, String gender, String department, int yearOfJoining, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.gender = gender;
		this.department = department;
		this.yearOfJoining = yearOfJoining;
		this.salary = salary;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public int getYearOfJoining() {
		return yearOfJoining;
	}

	public void setYearOfJoining(int yearOfJoining) {
		this.yearOfJoining = yearOfJoining;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", age=" + age + ", gender=" + gender + ", department="
				+ department + ", yearOfJoining=" + yearOfJoining + ", salary=" + salary + ", getId()=" + getId()
				+ ", getName()=" + getName() + ", getAge()=" + getAge() + ", getGender()=" + getGender()
				+ ", getDepartment()=" + getDepartment() + ", getYearOfJoining()=" + getYearOfJoining()
				+ ", getSalary()=" + getSalary() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}

	
	
}
