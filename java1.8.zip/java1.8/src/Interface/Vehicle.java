package Interface;

 interface Vehicle {
	public void start();
	
	/*
	 * public default void clean() { System.out.println("Clean...."); }//default method Override.
	 */
	
	public static void clean() {//static method can not be Override.
		System.out.println("Clean....");
	}

}
 class Car implements Vehicle{
	 
	 

		/*
		 * @Override public void clean() { System.out.println("my clean methode......");
		 * }
		 */
	@Override
	public void start() {
		System.out.println("car is started....");
		
	}
	public static void main(String args []) {
		Car c = new Car();
		c.start();
		//c.clean();//default method call object
		Vehicle.clean();//static method call interface name
	}
	
}
 
