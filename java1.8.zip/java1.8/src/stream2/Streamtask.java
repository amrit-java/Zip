package stream2;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import java.util.stream.Collectors;

//group by using Stream:-Group By used to categorize the data / Grouping the data
//When we use grouping () function with stream it will group the data as Key-Value pairs and it will return Map object
//example:-Employee will be grouped based on countryName
public class Streamtask {

	public static void main(String[] args) {
		Employee e1 = new Employee(1, "Robert", 26500.00,"USA");
		Employee e2 = new Employee(1, "Abraham", 46500.00,"INDIA");
		Employee e3 = new Employee(1, "Ching", 36500.00,"CHINA");
		Employee e4 = new Employee(1, "David", 16500.00,"INDIA");
		Employee e5 = new Employee(1, "Cathy", 25500.00,"JAPAN");
	
		List<Employee> list = Arrays.asList(e1,e2,e3,e4,e5);
		
		Map<String, List<Employee>> data = list.stream().collect(Collectors.groupingBy(e -> e.country));
		System.out.println(data);
		
		
	}

}

class Employee{
	int id;
	String name;
	double salary;
	String country;
	
	public Employee(int id, String name, double salary,String country) {
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.country=country;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", country=" + country + "]";
	}

	
	
	
}
