package stream2;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class MatchingOperationWithStream1 {

    public static void main(String[] args) {

        Person p1 = new Person("John", "USA");
        Person p2 = new Person("Steve", "JAPAN");
        Person p3 = new Person("Ashok", "INDIA");
        Person p4 = new Person("Ching", "CHINA");
        Person p5 = new Person("kumar", "INDIA");

        List<Person> persons = Arrays.asList(p1, p2, p3, p4,p5);

        // Use filter to find the first person from INDIA
        Optional<Person> findFirst = persons.stream()
                .filter(p -> p.country.equals("INDIA"))
                .findFirst();

        if (findFirst.isPresent()) {
            System.out.println(findFirst.get());
        }
    }
}

 class Person {
	 
    String name;
    String country;

    public Person(String name, String country) {
    	
        this.name = name;
        this.country = country;
    }

	@Override
	public String toString() {
		return "Person [name=" + name + ", country=" + country + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}

	
}
