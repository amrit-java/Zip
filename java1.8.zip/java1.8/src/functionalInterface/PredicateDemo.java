package functionalInterface;

import java.util.function.BiPredicate;
import java.util.function.Predicate;

public class PredicateDemo {//PREDICATE:-it is predefined functional interface,used to check condition and RETURN TRUE AND false value
	
/*	
	  public boolean test (int i) { if(i>10) { 
		  return true;
		  }else { 
			  return false; 
			  }
	  }*/
	 
	
	public static void main(String args []) {
		
		//using lembda
	  Predicate<Integer> p = (i) -> i > 10;
		//p.test(5);
		System.out.println(p.test(5));
		System.out.println(p.test(112));
		
		System.out.println("===================================");
		
		BiPredicate<Integer, Integer> bip=(i,j)-> (i+j)>=20;//Accept only two input
		System.out.println(bip.test(2, 3));//false
		System.out.println(bip.test(5, 5));//false 5+5=10 not greater than 20
		System.out.println(bip.test(5, 25));//true
	}

}
