package functionalInterface;

import java.util.function.BiFunction;
import java.util.function.Function;

public class FunctionDemo {

	public static void main(String[] args) {
		
		Function <String, Integer>f =(name)-> name.length();
		
		System.out.println(f.apply("ashokit"));
		System.out.println(f.apply("Amrit"));
		System.out.println(f.apply("delhi"));
		//first two Integer is input,other is output
		BiFunction<Integer,Integer,Integer> bifunction= (a,b)-> a+b;
				System.out.println(bifunction.apply(10, 20));

	}

}
