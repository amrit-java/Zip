package functionalInterface;

import java.util.function.Supplier;

//SUPLIER IS PREDEFINED FUNCTION INTERFACE INTRODUCE IN JAVA 1.8v
//IT CONTAINS ONLY ONE ABSTRACT MRTHODE THAT IS GET() METHODE
//SUPLIER INTERFACE WILL NOT TAKE ANY INPUT ,IT WILL ONLY RETURN THE VALUE.
//:EX:-OTP GENERATION
public class SupplierDemo {
	public static void main(String args []) {
		 
		Supplier<String> s = () -> {
			String otp="";
			 for(int i= 1; i <= 5;i++) {
				 otp = otp + (int)(Math.random()*10);
			 }
			 return otp;
		 };
		 System.out.println(s.get());
	}

}
