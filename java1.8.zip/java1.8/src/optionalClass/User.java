package optionalClass;

import java.util.Optional;

public class User {
	public String getUserById(Integer id) {

		if (id == 100) {
			return "Raju";
		} else if (id == 101) {
			return "John";
		} else if (id == 102) {
			return "Rani";
		} else {
			return null;
		}
	}
	
	public Optional<String> getUserById1(Integer id) {
          String name = null;
		if (id == 100) {
			name =  "Raju";
		} else if (id == 101) {
			name =  "John";
		} else if (id == 102) {
			name =  "Rani";
		
		}
		return Optional.ofNullable(name);
	}
}
