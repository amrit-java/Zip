package base64;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;
//base64 is a predefined class available in java.utilpackage
//
//salt:- extra text will be Encrtyped with password
public class PasswordService {
	public static void main(String[] args) throws Exception {
		
		String pwd = "amritbh0007@gmail.com";
		
	MessageDigest md = MessageDigest.getInstance("SHA-256");
	byte[] digest = md.digest(pwd.getBytes());
	String str = new String(digest);
	System.out.println("Encrtyped ::"+str);
	
	Encoder encoder = Base64.getEncoder();
	byte[] encode= encoder.encode(pwd.getBytes());
	System.out.println("Encrtyped + Encoded ::"+ new String(encode));
	
	/*Encoder encoder = Base64.getEncoder();//encoder object
	
	//converting String to byte[] and passing as input for encode() method
	byte[] encode= encoder.encode(pwd.getBytes());
	//converting byte[] to String
	String encodepwd =  new String(encode);
	System.out.println(encodepwd);
	
	Decoder decoder = Base64.getDecoder();
	byte[]decode= decoder.decode(encodepwd);
	String decodepwd = new String(decode);
	System.out.println(decodepwd );*/
	
	}
}
