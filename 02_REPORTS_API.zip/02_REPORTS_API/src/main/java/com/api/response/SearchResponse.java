package com.api.response;

import lombok.Data;

@Data
public class SearchResponse {
	
	private String name;
	private String mobile;
	private String email;
	private Character gender;
	private Long ssn;
	private String planName;
	private String planStatus;

}
