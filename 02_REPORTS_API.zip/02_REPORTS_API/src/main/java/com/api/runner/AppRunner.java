package com.api.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import com.api.entity.EligibilityDetails;
import com.api.repository.EligibilityDetailsRepo;

@Component
public class AppRunner implements ApplicationRunner {
	@Autowired
	private EligibilityDetailsRepo repo;

	@Override
	public void run(ApplicationArguments args) throws Exception {
		EligibilityDetails entity1=new EligibilityDetails();
		entity1.setEligId(1);
		entity1.setName("Amrit");
		entity1.setMobile(777982012l);
		entity1.setGender('M');
		entity1.setSsn(987556655l);
		entity1.setPlanName("SNAP");
		entity1.setPlanStatus("Approved");
		
		repo.save(entity1);
		
		EligibilityDetails entity2=new EligibilityDetails();
		entity2.setEligId(2);
		entity2.setName("Kanak");
		entity2.setMobile(896325874l);
		entity2.setGender('F');
		entity2.setSsn(558799654l);
		entity2.setPlanName("CCAP");
		entity2.setPlanStatus("Denied");
		
		repo.save(entity2);
		
		EligibilityDetails entity3=new EligibilityDetails();
		entity3.setEligId(3);
		entity3.setName("Nishant");
		entity3.setMobile(7895624555l);
		entity3.setGender('M');
		entity3.setSsn(58888799654l);
		entity3.setPlanName("Medical");
		entity3.setPlanStatus("Closed");
		
		repo.save(entity3);
		
	}

}
