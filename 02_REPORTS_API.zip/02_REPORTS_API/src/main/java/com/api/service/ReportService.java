package com.api.service;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import com.api.request.SearchRequest;
import com.api.response.SearchResponse;

public interface ReportService {
	
	public List<String> getUniquePlanNames();
	
	public List<String> getUniquePlanStatus();
	
	public List<SearchResponse> search(SearchRequest requset);
	
    public void generateExcel(HttpServletResponse response)throws Exception;
   // public HttpServletResponse generateExcel();
    
    
    public void generatePdf(HttpServletResponse response)throws Exception;
}
