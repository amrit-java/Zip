package in.am;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatafatchAjaxApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatafatchAjaxApplication.class, args);
	}

}
