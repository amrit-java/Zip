package com.example.emp.Service;

import com.example.emp.domain.Student;
import com.example.emp.repository.StudentRepository;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

@Service
public class ItextReportService {

    @Autowired
    private StudentRepository studentRepository;

    public byte[] generateStudentReport() throws Exception{
        // Fetch student records from the database
        List<Student> students = studentRepository.findAll();

        // Create a new document
        Document document = new Document();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        // Create a PdfWriter instance
        PdfWriter writer = PdfWriter.getInstance(document, baos);

        // Open the document
        document.open();

        // Add a title to the document
        Font titleFont = FontFactory.getFont(FontFactory.TIMES_ROMAN, 18, Font.BOLD);
        Paragraph title = new Paragraph("Student Records", titleFont);
        title.setAlignment(Paragraph.ALIGN_CENTER);
        document.add(title);

        // Add an empty line for spacing
        document.add(new Paragraph(" "));

        // Create a table for student records
        PdfPTable table = new PdfPTable(4); // Four columns: ID, Student Name, Section, Fee

        // Add table headers
        Font headerFont = FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD);
        table.addCell(new Paragraph("ID", headerFont));
        table.addCell(new Paragraph("Student Name", headerFont));
        table.addCell(new Paragraph("Section", headerFont));
        table.addCell(new Paragraph("Fee", headerFont));

        // Add student records to the table
        for (Student student : students) {
            table.addCell(student.getId().toString());
            table.addCell(student.getStudentname());
            table.addCell(student.getCourse());
            table.addCell(Double.toString(student.getFee()));
        }

        document.add(table);

     // Add page numbers
        PdfContentByte cb = writer.getDirectContent();
        for (int i = 1; i <= writer.getPageNumber(); i++) {
            // Create a rectangle (border) around the page
            Rectangle border = new Rectangle(document.left(), document.bottom(), document.right(), document.top());
            border.setBorder(Rectangle.BOX);
            border.setBorderWidth(1f); // You can adjust the border width
            cb.rectangle(border);

            ColumnText.showTextAligned(cb, PdfContentByte.ALIGN_CENTER,
                    new Paragraph("Page " + i),
                    (document.right() + document.left()) / 2,
                    document.bottom() - 18, 0);

        }

        // Close the document
        document.close();

        // Return the generated PDF as a byte array
        return baos.toByteArray();
    }
}
