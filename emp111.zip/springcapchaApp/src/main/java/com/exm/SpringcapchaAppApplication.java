package com.exm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringcapchaAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringcapchaAppApplication.class, args);
	}

}
