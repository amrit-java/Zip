package com.exm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringcapchaAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
